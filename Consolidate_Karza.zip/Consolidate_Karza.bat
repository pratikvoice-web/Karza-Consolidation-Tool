<# :
@echo off
setlocal
color 0B
title Karza Master Consolidation Dashboard
echo ======================================================
echo   KARZA DEEP-CONSOLIDATION ENGINE - v2026.006
echo ======================================================
set "currentDir=%~dp0"
powershell -noprofile -executionpolicy bypass -command "iex ([System.IO.File]::ReadAllText('%~f0'))"
echo.
echo Process Finished.
pause
exit /b
#>

# --- Master Logic ---

$currentFolder = $env:currentDir
if (-not $currentFolder) { $currentFolder = Get-Location }

$stateMap = @{ "01"="J&K"; "02"="HP"; "03"="Punjab"; "04"="Chandigarh"; "05"="Uttarakhand"; "06"="Haryana"; "07"="Delhi"; "08"="Rajasthan"; "09"="UP"; "10"="Bihar"; "11"="Sikkim"; "12"="Arunachal"; "13"="Nagaland"; "14"="Manipur"; "15"="Mizoram"; "16"="Tripura"; "17"="Meghalaya"; "18"="Assam"; "19"="WB"; "20"="Jharkhand"; "21"="Odisha"; "22"="Chhattisgarh"; "23"="MP"; "24"="Gujarat"; "26"="DNHDD"; "27"="Maharashtra"; "29"="Karnataka"; "30"="Goa"; "31"="Lakshadweep"; "32"="Kerala"; "33"="TN"; "34"="Puducherry"; "35"="A&N Islands"; "36"="Telangana"; "37"="Andhra Pradesh"; "38"="Ladakh"; "97"="UN Bodies"; "99"="Foreign Entities" }

# --- Robust Dashboard UI Function ---
$script:firstBarInPhase = $true

function Show-Dashboard-Bar (${current}, ${total}, ${taskLabel}, ${phaseTitle}) {
    $percent = [int]((${current} / ${total}) * 100)
    $width = 40
    $done = [int]($percent * $width / 100)
    $left = $width - $done
    $bar = "█" * $done + "░" * $left
    
    if (-not $script:firstBarInPhase) {
        $pos = $host.ui.RawUI.CursorPosition
        $pos.Y -= 2
        $host.ui.RawUI.CursorPosition = $pos
    }
    $script:firstBarInPhase = $false

    if (${taskLabel}.Length -gt 60) { ${taskLabel} = ${taskLabel}.Substring(0, 57) + "..." }
    
    Write-Host "      ${phaseTitle}: [${bar}] ${percent}% " -ForegroundColor Cyan
    Write-Host "      STATUS: ${taskLabel}".PadRight(85) -ForegroundColor Gray
    
    if (${current} -eq ${total}) { 
        Write-Host "" 
        $script:firstBarInPhase = $true
    }
}

function Is-ValidMonth($str) {
    if ($null -eq $str -or $str.Length -lt 5) { return $false }
    return $str -match "^[A-Za-z]{3}-\d{2}$"
}

function Get-ColLetter($n) {
    $s = ""; while ($n -gt 0) { $m = ($n - 1) % 26; $s = [char](65 + $m) + $s; $n = [int](($n - $m) / 26) }; return $s
}

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

try {
    Write-Host "`n[1/3] SCANNING DIRECTORY & IDENTIFYING ENTITIES..." -ForegroundColor Yellow
    $files = Get-ChildItem -Path $currentFolder -Filter *.xlsx | Where-Object { $_.Name -notlike "CONSOLIDATED_*" }
    if ($files.Count -eq 0) { Write-Host "!! No reports found." -ForegroundColor Red; return }

    $fileDataList = @()
    $fIdx = 0
    foreach ($f in $files) {
        $fIdx++
        Write-Progress -Activity "Scanning Files" -Status "Reading Profile: $($f.Name)" -PercentComplete (($fIdx / $files.Count) * 100)
        
        $wb = $excel.Workbooks.Open($f.FullName)
        $ws = $wb.Sheets.Item("Entity Profile")
        $b3 = $ws.Range("B3").Text.Trim()
        $b4 = $ws.Range("B4").Text.Trim()
        $b5 = $ws.Range("B5").Text.Trim()
        $b6 = $ws.Range("B6").Text.Trim()
        $wb.Close($false)
        
        $p = $b5
        if (-not $p -or $p.Length -ne 10) { 
            if ($b6.Length -ge 15) { $p = $b6.Substring(2, 10) } 
        }
        if (-not $p) { $p = "UNKNOWNPAN" }
        
        $n = $b4
        if ([string]::IsNullOrWhiteSpace($n) -or $n -eq "-" -or $n -eq "NA") { $n = $b3 }
        if ([string]::IsNullOrWhiteSpace($n)) { $n = "Unknown Entity" }
        $safeName = $n -replace '[\\/:*?""<>|]', '_'
        
        $code = if ($b6.Length -ge 15) { $b6.Substring(0, 2) } else { "00" }
        $suffix = if ($b6.Length -ge 15) { $b6.Substring($b6.Length - 3, 3) } else { "XXX" }
        
        $fileDataList += [PSCustomObject]@{
            File = $f; PAN = $p; TradeName = $safeName; GSTIN = $b6; StateCode = $code; Suffix = $suffix
        }
    }
    Write-Progress -Activity "Scanning Files" -Completed

    $entityGroups = @{}
    $entityNames = @{}
    foreach ($fd in $fileDataList) {
        $k = $fd.PAN
        if ($fd.PAN.Length -eq 10 -and $fd.PAN[3] -match 'P') {
            $k = "$($fd.PAN)_$($fd.TradeName)"
        }
        if (-not $entityGroups.ContainsKey($k)) {
            $entityGroups[$k] = New-Object System.Collections.Generic.List[PSObject]
            $entityNames[$k] = $fd.TradeName
        }
        $entityGroups[$k].Add($fd)
    }

    foreach ($entry in $entityGroups.GetEnumerator()) {
        $entityKey = [string]$entry.Key; $entityItems = $entry.Value
        $myPan = $entityItems[0].PAN
        $nameDisp = $entityNames[$entityKey]
        
        Write-Host "`n======================================================" -ForegroundColor White
        Write-Host " ACTIVE ENTITY: $nameDisp ($myPan)" -ForegroundColor Green
        Write-Host "======================================================" -ForegroundColor White

        $stateCounts = @{}
        foreach ($item in $entityItems) { $stateCounts[$item.StateCode]++ }

        $summaryData = @(); $matrixData = @(); $relatedPANs = @()
        $panToNameMap = @{}

        Write-Host "[2/3] EXTRACTING DATA..." -ForegroundColor Yellow
        $fIdx = 0
        foreach ($item in $entityItems) {
            $fIdx++
            $file = $item.File
            $sN = $stateMap[$item.StateCode]; if ($null -eq $sN) { $sN = "Unknown" }
            
            if ($stateCounts[$item.StateCode] -gt 1) {
                $stHead = "$($item.StateCode)-$sN-$($item.Suffix)"
            } else {
                $stHead = "$($item.StateCode)-$sN"
            }
            
            Show-Dashboard-Bar $fIdx $entityItems.Count "Reading $stHead ($($file.Name))" "EXTRACTION"
            $wb = $excel.Workbooks.Open($file.FullName)

            foreach ($rpS in @("Related Party Sales - Monthly", "Related Party Purchases-Monthly")) {
                try { $wsRP = $wb.Sheets.Item($rpS)
                    $rpMaxRow = $wsRP.UsedRange.Rows.Count + 50
                    for ($c=2; $c -le 200; $c+=8) { 
                        $blankStreak = 0
                        for ($r=4; $r -le $rpMaxRow; $r++) {
                            $rpP = $wsRP.Cells.Item($r, $c).Text.Trim()
                            if ($rpP.Length -eq 10) { 
                                $relatedPANs += $rpP
                                $blankStreak = 0
                            } else {
                                $blankStreak++
                                if ($blankStreak -gt 50) { break }
                            }
                        } 
                    }
                } catch {}
            }

            # --- GSTR1 FALLBACK LOGIC ---
            $wsG = $wb.Sheets.Item("GSTR1 vs 3B"); $fileMonths = @{}
            for ($i = 4; $i -le ($wsG.UsedRange.Rows.Count + 20); $i++) {
                $m = $wsG.Cells.Item($i, 1).Text.Trim()
                if (Is-ValidMonth $m) { 
                    $gt3b = 0; $gi3b = 0; $gt1 = 0; $gi1 = 0
                    try { $gi1 = [double]$wsG.Cells.Item($i, 2).Value2 } catch {}
                    try { $gt1 = [double]$wsG.Cells.Item($i, 3).Value2 } catch {}
                    try { $gi3b = [double]$wsG.Cells.Item($i, 4).Value2 } catch {}
                    try { $gt3b = [double]$wsG.Cells.Item($i, 5).Value2 } catch {}

                    $isFallback = $false
                    $gt = $gt3b; $gi = $gi3b

                    if ($gt -eq 0 -and $gt1 -gt 0) { $gt = $gt1; $isFallback = $true }
                    if ($gi -eq 0 -and $gi1 -gt 0) { $gi = $gi1; $isFallback = $true }

                    $fileMonths[$m] = @{ GT=$gt; GI=$gi; IT_C=0; II_C=0; IT_S=0; II_S=0; IsFallback=$isFallback }
                }
            }

            foreach ($type in @("Customer", "Supplier")) {
                $ws = $wb.Sheets.Item("$type Wise - Monthly Data")
                $maxRow = $ws.UsedRange.Rows.Count + 50
                
                for ($c = 1; $c -le 400; $c += 9) {
                    $m = $ws.Cells.Item(2, $c).Text.Trim()
                    if (-not $fileMonths.ContainsKey($m)) { continue }
                    
                    $blankStreak = 0
                    for ($r = 4; $r -le $maxRow; $r++) {
                        $cP = $ws.Cells.Item($r, $c + 1).Text.Trim()
                        $cN = $ws.Cells.Item($r, $c + 2).Text.Trim()
                        
                        if (-not $cP) { 
                            $blankStreak++
                            if ($blankStreak -gt 50) { break } 
                            continue 
                        }
                        $blankStreak = 0
                        
                        if ($cP -match '^(?i)total' -or $cN -match '^(?i)total$' -or $cN -match '^(?i)grand total$') { continue }
                        
                        if (-not [string]::IsNullOrWhiteSpace($cN) -and $cN -ne "-") { $panToNameMap[$cP] = $cN }
                        
                        $vT = 0; $vI = 0
                        try { $vT = [double]$ws.Cells.Item($r, $c + 3).Value2 } catch {}
                        try { $vI = [double]$ws.Cells.Item($r, $c + 5).Value2 } catch {}
                        
                        if ($vT -eq 0 -and $vI -eq 0) { continue }
                        
                        if ($cP -eq $myPan) {
                            if ($type -eq "Customer") { $fileMonths[$m].IT_C += $vT; $fileMonths[$m].II_C += $vI }
                            else { $fileMonths[$m].IT_S += $vT; $fileMonths[$m].II_S += $vI }
                        } else {
                            $matrixData += [PSCustomObject]@{ Name=$cN; PAN=$cP; State=$stHead; Month=$m; T=$vT; I=$vI; IsRP=($relatedPANs -contains $cP); Type=$type }
                        }
                    }
                }
            }
            foreach ($mK in $fileMonths.Keys) { 
                $d = $fileMonths[$mK]; 
                $summaryData += [PSCustomObject]@{ Month=$mK; State=$stHead; Type="Customer"; GT=$d.GT; GI=$d.GI; IT=$d.IT_C; II=$d.II_C; IsFallback=$d.IsFallback }; 
                $summaryData += [PSCustomObject]@{ Month=$mK; State=$stHead; Type="Supplier"; GT=$d.GT; GI=$d.GI; IT=$d.IT_S; II=$d.II_S; IsFallback=$d.IsFallback } 
            }
            $wb.Close($false)
        }

        foreach ($md in $matrixData) {
            if ([string]::IsNullOrWhiteSpace($md.Name) -or $md.Name -eq "-") {
                if ($panToNameMap.ContainsKey($md.PAN)) { $md.Name = $panToNameMap[$md.PAN] } else { $md.Name = "Unknown Party" }
            }
        }

        $months = ($summaryData.Month + $matrixData.Month) | Select-Object -Unique | Where-Object { $_ } | Sort-Object { [DateTime]::ParseExact($_, "MMM-yy", $null) }
        $states = $summaryData.State | Select-Object -Unique | Sort-Object
        $auditGT = ($summaryData | Where-Object { $_.Type -eq "Customer" } | Measure-Object GT -Sum).Sum
        $auditIT = ($summaryData | Where-Object { $_.Type -eq "Customer" } | Measure-Object IT -Sum).Sum
        Write-Host "`n  AUDIT SUMMARY (Taxable Revenue):" -ForegroundColor White
        Write-Host "  > Gross: INR $($auditGT.ToString('#,##0.00'))" -ForegroundColor White
        Write-Host "  > Net:   INR $(($auditGT-$auditIT).ToString('#,##0.00'))`n" -ForegroundColor Green

        Write-Host "[3/3] BUILDING WORKBOOK..." -ForegroundColor Yellow
        $outName = "CONSOLIDATED_${myPan}_${nameDisp}.xlsx"; $outPath = Join-Path $currentFolder $outName
        if (Test-Path $outPath) { try { Remove-Item $outPath -Force -ErrorAction Stop } catch { Write-Host "!! Close file and press key..."; $null = $Host.UI.RawUI.ReadKey(); Remove-Item $outPath -Force } }
        
        $outWb = $excel.Workbooks.Add(); $step = 0; $totalSteps = 9
        
        $netCfgs = @(
            @{N="Tax. Value - Internal Sales"; G="GT"; I="IT"; Tp="Customer"; L=@("Gross Revenue - Taxable Value", "Internal Sales - Taxable Value", "Net Revenue - Taxable Value")}, 
            @{N="Inv. Value - Internal Sales"; G="GI"; I="II"; Tp="Customer"; L=@("Gross Revenue - Invoice Value", "Internal Sales - Invoice Value", "Net Revenue - Invoice Value")}, 
            @{N="Tax. Value - Internal Purchases"; G="GT"; I="IT"; Tp="Supplier"; L=@("Gross Revenue - Taxable Value", "Internal Purchases - Taxable Value", "Net Revenue - Taxable Value")}, 
            @{N="Inv. Value - Internal Purchases"; G="GI"; I="II"; Tp="Supplier"; L=@("Gross Revenue - Invoice Value", "Internal Purchases - Invoice Value", "Net Revenue - Invoice Value")}
        )
        
        foreach ($cfg in $netCfgs) {
            $step++; Show-Dashboard-Bar $step $totalSteps "Writing: $($cfg.N)" "GENERATION"
            $ws = $outWb.Sheets.Add(); $ws.Name = $cfg.N; $r = 1
            
            for ($i=0; $i -lt 3; $i++) {
                $modeLabel = $cfg.L[$i]
                $modeLogic = @("Gross", "Internal", "Net")[$i]
                
                $ws.Cells.Item($r, 1).NumberFormat = "@"; $ws.Cells.Item($r, 1) = $modeLabel; $ws.Cells.Item($r, 1).Font.Bold = $true; $ws.Cells.Item($r+1, 1).NumberFormat = "@"; $ws.Cells.Item($r+1, 1) = "Month"; $cc = 2
                foreach ($s in $states) { $ws.Cells.Item($r+1, $cc++) = $s }; $ws.Cells.Item($r+1, $cc) = "Total"
                $dr = $r + 2; foreach ($m in $months) {
                    $ws.Cells.Item($dr, 1).NumberFormat = "@"; $ws.Cells.Item($dr, 1) = [string]$m; $cc = 2
                    foreach ($s in $states) {
                        $recs = $summaryData | Where-Object { $_.Month -eq $m -and $_.State -eq $s -and $_.Type -eq $cfg.Tp }
                        $v = 0; $hasFallback = $false
                        if ($recs) { 
                            if ($modeLogic -eq "Gross") { $v = ($recs | Measure-Object $($cfg.G) -Sum).Sum } 
                            elseif ($modeLogic -eq "Internal") { $v = ($recs | Measure-Object $($cfg.I) -Sum).Sum } 
                            else { $v = ($recs | Measure-Object $($cfg.G) -Sum).Sum - ($recs | Measure-Object $($cfg.I) -Sum).Sum } 
                            foreach ($rData in $recs) { if ($rData.IsFallback) { $hasFallback = $true; break } }
                        }
                        $ws.Cells.Item($dr, $cc) = $v
                        
                        # Apply Highlight if Fallback used (Gross and Net rows only)
                        if ($hasFallback -and $modeLogic -ne "Internal") {
                            $ws.Cells.Item($dr, $cc).Font.Italic = $true
                            $ws.Cells.Item($dr, $cc).Interior.ColorIndex = 36
                        }
                        $cc++
                    }
                    $ws.Cells.Item($dr, $cc).Formula = "=SUM(B${dr}:$(Get-ColLetter($cc-1))${dr})"; $dr++
                }
                $r = $dr + 2
            }
            $ws.UsedRange.EntireColumn.AutoFit() | Out-Null; $ws.UsedRange.NumberFormat = "#,##0.00" | Out-Null
        }

        $matrixCfgs = @(
            @{N="Detailed_Customer_Taxable"; D=$matrixData | Where-Object { $_.Type -eq "Customer" }; V="T"},
            @{N="Detailed_Customer_Invoice"; D=$matrixData | Where-Object { $_.Type -eq "Customer" }; V="I"},
            @{N="Detailed_Supplier_Taxable"; D=$matrixData | Where-Object { $_.Type -eq "Supplier" }; V="T"},
            @{N="Detailed_Supplier_Invoice"; D=$matrixData | Where-Object { $_.Type -eq "Supplier" }; V="I"}
        )

        foreach ($mCfg in $matrixCfgs) {
            $step++; Show-Dashboard-Bar $step $totalSteps "Matrixing: $($mCfg.N)" "GENERATION"
            $ws = $outWb.Sheets.Add(); $ws.Name = $mCfg.N; $ws.Outline.SummaryRow = 0 | Out-Null
            $ws.Cells.Item(1, 1).NumberFormat = "@"; $ws.Cells.Item(1, 1) = "Party / State"; $ws.Cells.Item(1, 2).NumberFormat = "@"; $ws.Cells.Item(1, 2) = "PAN"; $cc = 3
            foreach ($m in $months) { $ws.Cells.Item(1, $cc).NumberFormat = "@"; $ws.Cells.Item(1, $cc++) = [string]$m }
            $ws.Cells.Item(1, $cc) = "Total"; $ws.Range("1:1").Font.Bold = $true; $dr = 2
            foreach ($pg in ($mCfg.D | Group-Object PAN)) {
                $ws.Cells.Item($dr, 1) = $pg.Group[0].Name; $ws.Cells.Item($dr, 2) = $pg.Name; $ws.Rows.Item($dr).Font.Bold = $true; $ws.Rows.Item($dr).Interior.ColorIndex = if ($pg.Group[0].IsRP) { 36 } else { 15 }
                $cc = 3; foreach ($m in $months) { $v = ($pg.Group | Where-Object { $_.Month -eq $m } | Measure-Object $($mCfg.V) -Sum).Sum; if ($v -gt 0) { $ws.Cells.Item($dr, $cc) = $v }; $cc++ }
                $ws.Cells.Item($dr, $cc).Formula = "=SUM(C${dr}:$(Get-ColLetter($cc-1))${dr})"; $pRow = $dr; $dr++
                foreach ($sg in ($pg.Group | Group-Object State)) {
                    $ws.Cells.Item($dr, 1) = "   >> " + $sg.Name; $cc = 3
                    foreach ($m in $months) { $v = ($sg.Group | Where-Object { $_.Month -eq $m } | Measure-Object $($mCfg.V) -Sum).Sum; if ($v -gt 0) { $ws.Cells.Item($dr, $cc) = $v }; $cc++ }
                    $ws.Cells.Item($dr, $cc).Formula = "=SUM(C${dr}:$(Get-ColLetter($cc-1))${dr})"; $dr++
                }
                if ($dr - 1 -gt $pRow) { $ws.Rows.Item("$(${pRow}+1):$(${dr}-1)").Group() | Out-Null }
            }
            $ws.UsedRange.EntireColumn.AutoFit() | Out-Null; $ws.UsedRange.NumberFormat = "#,##0.00" | Out-Null
        }

        $step++; Show-Dashboard-Bar $step $totalSteps "Finalizing glossary..." "GENERATION"
        $wsG = $outWb.Sheets.Add(); $wsG.Name = "Audit_Glossary"
        $wsG.Cells.Item(1, 1) = "Color Key"; $wsG.Cells.Item(1, 1).Font.Bold = $true
        $wsG.Cells.Item(3, 1).Interior.ColorIndex = 36; $wsG.Cells.Item(3, 2) = "Related Party (Matrix Sheets)"
        $wsG.Cells.Item(4, 1).Interior.ColorIndex = 15; $wsG.Cells.Item(4, 2) = "Third Party (Matrix Sheets)"
        $wsG.Cells.Item(5, 1).Interior.ColorIndex = 36; $wsG.Cells.Item(5, 1).Font.Italic = $true; $wsG.Cells.Item(5, 2) = "GSTR1 Fallback Value (Revenue Sheets - Indicates missing GSTR3B data)"
        $wsG.UsedRange.EntireColumn.AutoFit() | Out-Null
        
        $outWb.SaveAs($outPath, 51) | Out-Null; $outWb.Close($false) | Out-Null
        
        Write-Host "`n[SUCCESS] CONSOLIDATION COMPLETE" -ForegroundColor Green
        Write-Host "  FILE: $outPath" -ForegroundColor Yellow
        explorer.exe "/select,`"$outPath`""
    }
} catch { Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red } finally {
    if ($null -ne $excel) { $excel.Quit(); [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null }
}